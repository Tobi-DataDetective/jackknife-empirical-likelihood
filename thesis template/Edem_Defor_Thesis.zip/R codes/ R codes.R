##The MPL function##

mplfunc<-function(N,reps,t){
  k.n=rep(0,reps)
  summ1=0;summ2=0
  mylist=rep(list(rep(0,N)),reps)
  for(i in 1:reps)
  {
    ###This part changes depending on the distribution###
    T.order=sort(runif(N))  
    while(max(T.order)<t) 
    {T.order=sort(runif(N))}
    ###change ends here###
    mylist[[i]]=T.order
    for(k in 1:N)
    {
      if (t>=T.order[k]&t<T.order[k+1]){ 
        for(j in 1:k)
          summ1=summ1+T.order[j]
      }
      else
        summ1=0
      summ2=summ2+summ1/k
      summ1=0
    }
    k.n[i]=t-summ2
    summ2=0
  }
  return(list(k.n,mylist))
}

##The empirical likelihood##

partEL=function(act,xx,t){
  z_n <- xx[xx<t]
  z_n <- t - z_n - act
  tt = el.test(x=z_n,mu=0)
  ll = tt$"-2LLR"
  out = list("-2LLR"=ll,xx,t=t,act=act)
  return(out)
}

##The adjusted empirical likelihood##

partAEL=function(act,xx,t){
  z_n <- xx[xx<t]
  z_n <-  t - z_n - act
  tt = el.test.Adj(x=z_n,mu=0)
  ll = tt$"-2LLR"
  out = list("-2LLR"=ll,xx,t=t,act=act)
  return(out)
}

##The mean empirical likelihood##

partMEL=function(act,xx,t){
  z_n <- xx[xx<t]
  z_n <- t - z_n - act
  rm <- meanMEL(z_n)
  tt = el.test(x = rm,mu=0)
  ll = tt$"-2LLR"
  ll = ll/(length(z_n)+1)
  out = list("-2LLR"=ll,xx,t=t,act=act)
  return(out)
}
meanMEL=function(m_n){
  data_n=y=0
  n = length(m_n)
  for(i in 1:n){
    for(j in i:n){
      y=y+1 
      data_n[y]=mean(c(m_n[i],m_n[j]))
    } }
  return(data_n)
}

##Coverage for a uniform distribution at time 0.8##
N=100;t=0.8;reps=2000;act=t/2
data=mplfunc(N,reps,t)
low=high=0

for(i in 1:reps){
  x_x = data[[2]][[i]]
  ml = data[[1]][[i]]
  ci= findUL(step=0.1,fun=partEL,MLE=ml,xx=x_x ,t=t)
  low[i]=ci$Low;high[i]=ci$Up
}
mar=mean((low<act)&(high>act))
cat("The coverage probability is: ",mar)

avg=mean(high-low)
cat("The average length is: ",avg) 